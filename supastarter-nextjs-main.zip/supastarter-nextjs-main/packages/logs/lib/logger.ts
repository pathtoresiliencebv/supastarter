import { createConsola } from "consola";

export const logger = createConsola({
	formatOptions: {
		date: false,
	},
});
