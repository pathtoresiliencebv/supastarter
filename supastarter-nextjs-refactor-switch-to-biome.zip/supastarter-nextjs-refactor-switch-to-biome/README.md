<img src="./supastarter-logo-light.svg#gh-light-mode-only" alt="supastarter" width="300px" />
<img src="./supastarter-logo-dark.svg#gh-dark-mode-only" alt="supastarter" width="300px" />

# supastarter – next.js

supastarter is the ultimate starter kit for production-ready, scalable SaaS applications.

## Helpful links

- [📘 Documentation](https://docs.supastarter.dev)
- [🚀 Demo](https://demo.supastarter.dev)
- [💬 Discord](https://discord.gg/RUSASaAj4V)
