import type messages from "./translations/en.json";

export type Messages = typeof messages;
