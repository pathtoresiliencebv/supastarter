import { VerifyTokenView } from "@saas/auth/components/VerifyTokenView";

export default function VerifyTokenPage() {
  return <VerifyTokenView />;
}
