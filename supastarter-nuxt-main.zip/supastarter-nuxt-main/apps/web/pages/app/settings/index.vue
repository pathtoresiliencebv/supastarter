<script setup lang="ts">
  const localePath = useLocalePath();
  await navigateTo(localePath("/app/settings/account/general"));
</script>

<template>
  <div />
</template>
