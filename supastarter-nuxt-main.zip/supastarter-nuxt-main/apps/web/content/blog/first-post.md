---
title: Favorite Things
description: In this post I'm going to tell you about my favorite things.
draft: false
image:
  src: "/images/blog/cover.png"
date: 2023-02-28
authorName: Elon Musk
authorImage: /images/blog/author2.jpg
tags: [first, post]
---

## This is a heading

And we also have some great content here. What do you think?
