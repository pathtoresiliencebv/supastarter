<script lang="ts" setup>
  const localePath = useLocalePath();
  await navigateTo(localePath("/app/admin/users"));
</script>

<template>
  <div />
</template>
