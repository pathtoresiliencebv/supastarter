---
title: Terms and conditions
---

This is a placeholder text for your terms of service. Edit the file `content/legal/terms.md` to add your own content.
