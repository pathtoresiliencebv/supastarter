export const CURRENT_TEAM_ID_COOKIE_NAME = "current-team-id";
