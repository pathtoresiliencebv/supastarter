<template>
  <Alert>
    <MailCheckIcon class="size-6" />
    <AlertTitle>{{ $t("auth.teamInvitation.title") }}</AlertTitle>
    <AlertDescription>{{
      $t("auth.teamInvitation.description")
    }}</AlertDescription>
  </Alert>
</template>
