import { VerifyTokenView } from "@saas/auth/components/VerifyTokenView";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export default function VerifyTokenPage() {
	return <VerifyTokenView />;
}
