---
title: Privacy policy
---

This is a placeholder text for your privacy policy. Edit the file `content/legal/privacy-policy.md` to add your own content.
