import { githubCallbackRouteHandler } from "auth/oauth/github";

export default defineEventHandler(githubCallbackRouteHandler);
