export { googleRouteHandler as GET } from "auth/oauth/google";
