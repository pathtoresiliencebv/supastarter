import { googleRouteHandler } from "auth/oauth/google";

export default defineEventHandler(googleRouteHandler);
