<template>
  <MarketingNavBar />
  <main class="min-h-screen">
    <slot />
  </main>
  <MarketingFooter />
</template>
