<template>
  <div class="flex min-h-screen w-full items-center justify-center bg-muted">
    <div class="animate-pulse">
      <Logo />
    </div>
  </div>
</template>
