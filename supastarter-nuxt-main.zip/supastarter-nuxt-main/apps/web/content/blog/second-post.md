---
title: Awesome second post
description: This is my first post. I'm so excited!
draft: false
image:
  src: /images/blog/cover.png
date: 2023-03-01
authorName: Tony Stark
authorImage: /images/blog/author.jpg
tags: [first, post]
---

## Hello world

This is my first post. I'm so excited! This blog posts needs some more text lines to fill up the page, so I'm just going to write some random stuff here. I'm going to write about my favorite things, like:

### What's next?

I'm going to write a lot more posts. I'm going to write about my favorite things, like:

- Cats
- Dogs
- Pizza

You can even add some nice links here:

- [My favorite cat](https://www.youtube.com/watch?v=5dsGWM5XGdg)
- [My favorite dog](https://www.youtube.com/watch?v=5dsGWM5XGdg)
- [My favorite pizza](https://www.youtube.com/watch?v=5dsGWM5XGdg)
- [Homepage](/)
