import { githubRouteHandler } from "auth/oauth/github";

export default defineEventHandler(githubRouteHandler);
