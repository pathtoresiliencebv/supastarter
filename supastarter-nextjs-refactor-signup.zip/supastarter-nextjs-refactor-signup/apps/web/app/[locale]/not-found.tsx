import { redirect } from "@i18n";

export default function NotFoundPage() {
	return redirect("/404");
}
