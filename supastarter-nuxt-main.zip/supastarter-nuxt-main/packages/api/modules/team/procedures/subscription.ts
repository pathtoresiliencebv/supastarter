import { SubscriptionSchema, db } from "database";
import { z } from "zod";
import { protectedProcedure } from "../../trpc";

export const subscription = protectedProcedure
  .input(
    z.object({
      teamId: z.string(),
    }),
  )
  .output(SubscriptionSchema.nullable())
  .query(async ({ input: { teamId }, ctx: { abilities } }) => {
    if (!abilities.isTeamMember(teamId)) {
      throw new Error("Unauthorized");
    }

    const subscription = await db.subscription.findUnique({
      where: {
        teamId,
      },
    });

    return subscription;
  });
