export { googleCallbackRouteHandler as GET } from "auth/oauth/google";
