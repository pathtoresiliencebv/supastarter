describe("homepage", () => {
	beforeEach(() => {
		cy.visit("/");
	});
});
