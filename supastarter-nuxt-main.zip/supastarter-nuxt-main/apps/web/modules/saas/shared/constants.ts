export const CURRENT_TEAM_ID_COOKIE = "current-team-id";
