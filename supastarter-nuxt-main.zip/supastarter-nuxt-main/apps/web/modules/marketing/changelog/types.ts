export type ChangelogItem = {
  date: string;
  changes: string[];
};
