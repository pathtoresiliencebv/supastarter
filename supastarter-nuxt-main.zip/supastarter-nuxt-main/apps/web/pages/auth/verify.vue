<script setup lang="ts">
  definePageMeta({
    layout: "saas-auth",
  });
</script>

<template>
  <SaasVerifyTokenView />
</template>
