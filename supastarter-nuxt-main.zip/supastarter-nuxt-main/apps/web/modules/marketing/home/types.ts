export type FAQ = {
  question: string;
  answer: string;
};
