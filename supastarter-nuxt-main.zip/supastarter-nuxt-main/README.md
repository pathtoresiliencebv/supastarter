# supastarter for Nuxt

supastarter is the ultimate starter kit for production-ready, scalable SaaS applications.

## Helpful links

- [📘 Documentation](https://supastarter.dev/docs/nuxt)
- [🚀 Demo](https://nuxt-demo.supastarter.dev)
- [💬 Discord](https://discord.gg/BZDNtf8hqt)
