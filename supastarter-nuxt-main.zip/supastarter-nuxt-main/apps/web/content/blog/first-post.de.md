---
title: Lieblingsdinge
description: Hier schreibe ich über meine Lieblingsdinge.
draft: false
image:
  src: "/images/blog/cover.png"
date: 2023-02-28
authorName: Elon Musk
authorImage: /images/blog/author2.jpg
tags: [first, post]
---

## Meine Lieblingsdinge

Das ist ein Testpost. Hier schreibe ich über meine Lieblingsdinge.
