import { NotFound } from "@marketing/shared/components/NotFound";

export default function NotFoundPage() {
	return <NotFound />;
}
