export const config = {
  from: "contact@supastarter.dev",
};
