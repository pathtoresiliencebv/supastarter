import { webhookHandler } from "billing";

export { webhookHandler as POST };
