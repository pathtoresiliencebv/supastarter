<script lang="ts" setup>
  definePageMeta({
    layout: "saas-app",
  });
</script>

<template>
  <SaasAdminUserList />
</template>
