import { atom } from "jotai";

export const sidebarExpanded = atom<boolean>(false);
