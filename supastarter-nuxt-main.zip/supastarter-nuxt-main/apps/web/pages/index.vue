<script setup lang="ts">
  definePageMeta({
    layout: "marketing",
  });
</script>

<template>
  <MarketingHero />
  <MarketingFeatures />
  <MarketingFaqSection />
  <MarketingNewsletter />
</template>
