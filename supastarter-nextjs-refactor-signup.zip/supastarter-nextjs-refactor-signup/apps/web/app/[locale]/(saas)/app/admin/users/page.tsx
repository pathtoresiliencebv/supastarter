import { UserList } from "@saas/admin/component/UserList";

export default function AdminUserPage() {
	return (
		<div>
			<UserList />
		</div>
	);
}
