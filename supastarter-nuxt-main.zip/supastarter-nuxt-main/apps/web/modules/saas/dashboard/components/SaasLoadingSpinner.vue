<script setup lang="ts">
  import { LoaderIcon } from "lucide-vue-next";
</script>

<template>
  <div class="flex items-center justify-center py-8">
    <LoaderIcon class="size-4 animate-spin text-3xl text-primary" />
  </div>
</template>
