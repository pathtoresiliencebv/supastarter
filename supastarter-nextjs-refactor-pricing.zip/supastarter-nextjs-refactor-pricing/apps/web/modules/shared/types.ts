import type { ApiOutput } from "api/trpc/router";

export type Purchases = ApiOutput["billing"]["purchases"];
