import { atom } from "jotai";

export const sidebarExpanded = atom<boolean>(false);

export const createTeamDialogOpen = atom<boolean>(false);
