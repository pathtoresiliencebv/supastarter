import { googleCallbackRouteHandler } from "auth/oauth/google";

export default defineEventHandler(googleCallbackRouteHandler);
